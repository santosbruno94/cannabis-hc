# Bruno Leite Advocacia — Landing Page UI Kit

A high-fidelity recreation of the brunoleite.adv.br landing page broken into reusable JSX components. All visuals lifted directly from the source `index.html` — colors, type, spacing, copy.

## Components
- `Nav.jsx` — sticky top nav with brand wordmark + OAB number + gold-outline CTA
- `Hero.jsx` — split hero with editorial italic headline + circular brand emblem
- `Section.jsx` — generic section wrapper with eyebrow + title + body slot
- `Steps.jsx` — 4-up numbered process steps with connecting hairline
- `DocsTable.jsx` — Roman-numeral document category table
- `Callout.jsx` — italic pull-quote with gold left-border
- `CheckList.jsx` — arrow-bulleted list
- `WhoCard.jsx` — lawyer profile card with photo medallion + tags
- `FAQ.jsx` — accordion with `+` → `×` glyph
- `CTASection.jsx` — green-bg conversion section
- `Footer.jsx` — minimal navy-deep footer
- `WhatsAppFloat.jsx` — fixed bottom-right WhatsApp button

## Notes
- All copy lifted verbatim from the source page; intended as a faithful recreation, not a new design.
- Logo SVG referenced from `../../assets/logo-gold.svg`. Lawyer photo from `../../assets/bruno-leite.jpg`.
- Open `index.html` in this folder to see the assembled page.
